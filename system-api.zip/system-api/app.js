// criando a constante express
// fazendo o require, importando a biblioteca
// buscando a biblioteca
const express = require('express');

// chamando o metedo construidor, o express
const app = express();

// exportando para a chamada, podendo agora ser usado
module.exports = app;